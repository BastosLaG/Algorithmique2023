#ifndef PARENTHESE_H
#define PARENTHESE_H

	struct Parenthese_Func
	{
		void (*recursive)(int);	
		void (*iterative)(int);
		void (*tests)(void (*)(int));
	};
	extern const struct Parenthese_Func Parenthese;
#endif