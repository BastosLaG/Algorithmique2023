#ifndef CATALAN_H
#define CATALAN_H

	struct Catalan_Func
	{
		unsigned long (*coefficient_binomial)(const unsigned long);	
		unsigned long (*iterative)(const unsigned long);
		unsigned long (*recursive)(const unsigned long);
		void (*tests)(unsigned long (*)(const unsigned long));
	};
	extern const struct Catalan_Func Catalan;
#endif